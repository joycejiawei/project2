var myMap = L.map("map", {
    center: [40.7388, -74.006],
    zoom: 13,
    layer: [light, pricelayer, starlayer, ratinglayer]
  });
  
var hotelsdata = [
    {Hotel_name:'The Surrey, New York',price:581,hotel_star:5,rating:4.5,lat_long:[40.774487, -73.963871]},
{Hotel_name:'Gramercy Park Hotel, New York',price:408,hotel_star:5,rating:4.3,lat_long:[40.738481, -73.985496]},
{Hotel_name:'DoubleTree by Hilton New York City - Financial District, New York',price:152,hotel_star:4,rating:3.8,lat_long:[40.70402, -74.01242]},
{Hotel_name:'Residence Inn Marriott New York Downtown Manhattan/WTC Area, New York',price:148,hotel_star:3.5,rating:4.5,lat_long:[40.709657, -74.010093]},
{Hotel_name:'The Sherry Netherland, New York',price:45,hotel_star:4.5,rating:4.8,lat_long:[40.76453, -73.97285]},
{Hotel_name:'The Franklin Hotel, New York',price:207,hotel_star:3.5,rating:3.4,lat_long:[40.779886, -73.954404]},
{Hotel_name:'Orchard Street Hotel, New York',price:125,hotel_star:3,rating:3.9,lat_long:[40.721083, -73.988709]},
{Hotel_name:'Staybridge Suites Times Square, New York',price:125,hotel_star:3.5,rating:4.2,lat_long:[40.756731, -73.992607]},
{Hotel_name:'Fairfield Inn & Suites New York Manhattan/Downtown East, New York',price:11,hotel_star:2.5,rating:4.3,lat_long:[40.713128, -73.992859]},
{Hotel_name:'City Club Hotel, New York',price:12,hotel_star:4,rating:4.3,lat_long:[40.755772, -73.982292]},
{Hotel_name:'Best Western Plus Hospitality House, New York',price:150,hotel_star:2.5,rating:4.4,lat_long:[40.755593, -73.972159]},
{Hotel_name:'Holiday Inn Express New York City- Wall Street, New York',price:6,hotel_star:3,rating:4.1,lat_long:[40.705437, -74.007122]},
{Hotel_name:'W New York - Union Square, New York',price:314,hotel_star:4.5,rating:4.3,lat_long:[40.73653, -73.98899]},
{Hotel_name:'Four Seasons Hotel New York Downtown, New York',price:555,hotel_star:5,rating:4.8,lat_long:[40.712544, -74.009306]},
{Hotel_name:'Dylan Hotel NYC, New York',price:170,hotel_star:4,rating:3.8,lat_long:[40.75193, -73.97926]},
{Hotel_name:'The William, New York',price:17,hotel_star:4,rating:4.6,lat_long:[40.75057, -73.98019]},
{Hotel_name:'Refinery Hotel, New York',price:17,hotel_star:5,rating:4.6,lat_long:[40.752109, -73.985461]},
{Hotel_name:'The Chatwal, a Luxury Collection Hotel, New York City, New York',price:525,hotel_star:5,rating:4.6,lat_long:[40.7565, -73.98458]},
{Hotel_name:'Courtyard by Marriott New York Manhattan / Chelsea, New York',price:127,hotel_star:3.5,rating:4.5,lat_long:[40.74803, -73.9914]},
{Hotel_name:'Pod 39, New York',price:11,hotel_star:3,rating:4.2,lat_long:[40.749285, -73.976698]},
{Hotel_name:'Incentra Village Hotel, New York',price:188,hotel_star:3,rating:4.1,lat_long:[40.738, -74.004299]},
{Hotel_name:'Hotel 48LEX New York, New York',price:187,hotel_star:4.5,rating:4.2,lat_long:[40.75525, -73.9732]},
{Hotel_name:'The Peninsula New York, New York',price:745,hotel_star:5,rating:4.7,lat_long:[40.76165, -73.9749]},
{Hotel_name:'GEM Hotel - Chelsea, New York',price:134,hotel_star:3,rating:3.9,lat_long:[40.7447, -73.9991]},
{Hotel_name:'Holiday Inn Express Manhattan Times Square South, New York',price:126,hotel_star:3,rating:4.2,lat_long:[40.751079, -73.98685]},
{Hotel_name:'Cambria Hotel New York - Times Square, New York',price:118,hotel_star:3,rating:4.5,lat_long:[40.756682, -73.98049]},
{Hotel_name:'Chambers Hotel, New York',price:251,hotel_star:4,rating:4.4,lat_long:[40.76249, -73.9749]},
{Hotel_name:'NoMo SoHo, New York',price:148,hotel_star:4.5,rating:4.2,lat_long:[40.719921, -74.000304]},
{Hotel_name:'The Pierre, A Taj Hotel, New York, New York',price:55,hotel_star:5,rating:4.7,lat_long:[40.765341, -73.972221]},
{Hotel_name:'Hampton Inn Manhattan-Seaport-Financial District, New York',price:134,hotel_star:3,rating:4.1,lat_long:[40.709012, -74.002244]},
{Hotel_name:'The Manhattan at Times Square Hotel, New York',price:4,hotel_star:4,rating:3.1,lat_long:[40.762045, -73.982587]},
{Hotel_name:'Renaissance New York Hotel 57, New York',price:146,hotel_star:4,rating:4.1,lat_long:[40.761028, -73.969514]},
{Hotel_name:'Soho Garden Hotel, New York',price:1,hotel_star:2.5,rating:3.9,lat_long:[40.719179, -74.001653]},
{Hotel_name:'1 Hotel Central Park, New York',price:28,hotel_star:5,rating:4.6,lat_long:[40.764834, -73.976847]},
{Hotel_name:'SIXTY SoHo, New York',price:15,hotel_star:4.5,rating:4.6,lat_long:[40.724026, -74.003338]},
{Hotel_name:'The Beekman, A Thompson Hotel, New York',price:32,hotel_star:5,rating:4.7,lat_long:[40.711373, -74.00669]},
{Hotel_name:'InterContinental - New York Times Square, New York',price:201,hotel_star:5,rating:4.2,lat_long:[40.758741, -73.989322]},
{Hotel_name:'Hilton Garden Inn New York/West 35th Street, New York',price:8,hotel_star:3,rating:4.4,lat_long:[40.750216, -73.986721]},
{Hotel_name:'11 Howard, New York',price:21,hotel_star:5,rating:4.3,lat_long:[40.719249, -73.999993]},
{Hotel_name:'Holiday Inn Express New York - Manhattan West Side, New York',price:105,hotel_star:3,rating:4.1,lat_long:[40.764167, -73.994468]},
{Hotel_name:'Walker Hotel Greenwich Village, New York',price:235,hotel_star:4.5,rating:4.4,lat_long:[40.736297, -73.996547]},
{Hotel_name:'Seton Hotel, New York',price:100,hotel_star:3,rating:4.1,lat_long:[40.749761, -73.976188]},
{Hotel_name:'Windsor Hotel, New York',price:136,hotel_star:2,rating:2.7,lat_long:[40.71873, -73.99269]},
{Hotel_name:'Best Western Premier Herald Square, New York',price:110,hotel_star:3,rating:4.4,lat_long:[40.750525, -73.985563]},
{Hotel_name:'The Surrey, New York',price:581,hotel_star:5,rating:4.5,lat_long:[40.774487, -73.963871]},
{Hotel_name:'The Watson Hotel, New York',price:4,hotel_star:3.5,rating:3.9,lat_long:[40.76823, -73.98745]},
{Hotel_name:'The Benjamin, New York',price:1,hotel_star:4.5,rating:4.4,lat_long:[40.756384, -73.972087]},
{Hotel_name:'Holiday Inn Express New York City Times Square, New York',price:110,hotel_star:3,rating:3.9,lat_long:[40.756194, -73.993219]},
{Hotel_name:'Cassa Hotel NY 45th Street, New York',price:180,hotel_star:4,rating:4.4,lat_long:[40.756473, -73.982168]},
{Hotel_name:'New York Marriott East Side, New York',price:206,hotel_star:4,rating:4.1,lat_long:[40.75553, -73.97305]},
{Hotel_name:'The Kimberly Hotel, New York',price:218,hotel_star:4,rating:4.7,lat_long:[40.756137, -73.971505]},
{Hotel_name:'The Lex NYC, New York',price:14,hotel_star:3.5,rating:4.4,lat_long:[40.740169, -73.984262]},
{Hotel_name:'The Mark, New York',price:65,hotel_star:5,rating:4.8,lat_long:[40.775147, -73.963432]},
{Hotel_name:'Hampton Inn Manhattan-Chelsea, New York',price:101,hotel_star:3,rating:4.3,lat_long:[40.743825, -73.992972]},
{Hotel_name:'Edge Hotel, New York',price:20,hotel_star:3.5,rating:4.4,lat_long:[40.840226, -73.937751]},
{Hotel_name:'Green Holidays Apartments, New York',price:4,hotel_star:3.5,rating:3.1,lat_long:[40.747301, -73.98775]},
{Hotel_name:'Stewart Hotel, New York',price:116,hotel_star:4,rating:3.8,lat_long:[40.74892, -73.99218]},
{Hotel_name:'Fifty Hotel & Suites by Affinia, New York',price:125,hotel_star:4,rating:4.2,lat_long:[40.7561, -73.971]},
{Hotel_name:'Candlewood Suites New York City-Times Square, New York',price:115,hotel_star:3,rating:4.1,lat_long:[40.756149, -73.993114]},
{Hotel_name:'Shelburne Hotel & Suites by Affinia, New York',price:174,hotel_star:4,rating:4.1,lat_long:[40.748379, -73.97789]},
{Hotel_name:'Hilton New York Fashion District, New York',price:107,hotel_star:4,rating:4.3,lat_long:[40.745722, -73.993641]},
{Hotel_name:'Arlo SoHo, New York',price:144,hotel_star:4,rating:4.4,lat_long:[40.724241, -74.007842]},
{Hotel_name:'Hampton Inn Madison Square Garden Area Hotel, New York',price:110,hotel_star:3,rating:4.3,lat_long:[40.748256, -73.990032]},
{Hotel_name:'Duane Street Hotel Tribeca, New York',price:13,hotel_star:4,rating:4.3,lat_long:[40.716039, -74.007309]},
{Hotel_name:'Fitzpatrick Manhattan Hotel, New York',price:178,hotel_star:4,rating:4.5,lat_long:[40.76072, -73.969295]},
{Hotel_name:'Hotel Mulberry, New York',price:13,hotel_star:3,rating:4.5,lat_long:[40.715425, -73.999515]},
{Hotel_name:'DoubleTree by Hilton New York Times Square West, New York',price:5,hotel_star:4,rating:4,lat_long:[40.75682, -73.99298]},
{Hotel_name:'WestHouse New York, New York',price:155,hotel_star:5,rating:4.2,lat_long:[40.764421, -73.98144]},
{Hotel_name:'Hotel On Rivington, New York',price:266,hotel_star:4,rating:4.2,lat_long:[40.71983, -73.98806]},
{Hotel_name:'Hilton Garden Inn New York/Midtown Park Ave, New York',price:100,hotel_star:3.5,rating:4.4,lat_long:[40.746662, -73.982421]},
{Hotel_name:'Homewood Suites New York/Midtown Manhattan Times Square, New York',price:12,hotel_star:3.5,rating:4.5,lat_long:[40.754452, -73.993009]},
{Hotel_name:'The Langham, New York, Fifth Avenue, New York',price:401,hotel_star:5,rating:4.7,lat_long:[40.750089, -73.983368]},
{Hotel_name:'Hampton Inn Manhattan Grand Central, New York',price:114,hotel_star:3,rating:4.4,lat_long:[40.750738, -73.972332]},
{Hotel_name:'The Marcel at Gramercy, New York',price:12,hotel_star:4,rating:4.1,lat_long:[40.739362, -73.982337]},
{Hotel_name:'The Ridge Hotel, New York',price:104,hotel_star:3,rating:4.2,lat_long:[40.72287, -73.9894]},
{Hotel_name:'INNSIDE by MeliÃƒÂ  New York Nomad, New York',price:172,hotel_star:4.5,rating:4.4,lat_long:[40.746178, -73.992745]},
{Hotel_name:'Hotel St. James, New York',price:231,hotel_star:2.5,rating:3.8,lat_long:[40.757036, -73.983307]},
{Hotel_name:'Courtyard by Marriott New York Manhattan/Upper East Side, New York',price:11,hotel_star:3.5,rating:4.1,lat_long:[40.780392, -73.945881]},
{Hotel_name:'Hotel Edison, New York',price:87,hotel_star:3.5,rating:3.8,lat_long:[40.759797, -73.986025]},
{Hotel_name:'Courtyard by Marriott New York Manhattan / Central Park, New York',price:17,hotel_star:3.5,rating:4.3,lat_long:[40.764207, -73.98246]},
{Hotel_name:'Hotel Mimosa, New York',price:153,hotel_star:2.5,rating:4.1,lat_long:[40.714312, -73.993821]},
{Hotel_name:'YOTEL New York, New York',price:12,hotel_star:4,rating:4.2,lat_long:[40.759184, -73.995798]},
{Hotel_name:'The Townhouse Inn of Chelsea, New York',price:1,hotel_star:3.5,rating:4.5,lat_long:[40.743407, -73.993995]},
{Hotel_name:'Residence Inn New York Manhattan/Central Park, New York',price:21,hotel_star:3.5,rating:4.4,lat_long:[40.764265, -73.982452]},
{Hotel_name:'Four Points by Sheraton Midtown-Times Square, New York',price:115,hotel_star:3.5,rating:4.2,lat_long:[40.756587, -73.992239]},
{Hotel_name:'Sanctuary NYC Retreats, New York',price:134,hotel_star:3,rating:4.6,lat_long:[40.719832, -73.983133]},
{Hotel_name:'Royalton Park Avenue, New York',price:150,hotel_star:5,rating:4.3,lat_long:[40.743857, -73.983766]},
{Hotel_name:'Roxy Hotel Tribeca, New York',price:21,hotel_star:4.5,rating:4.5,lat_long:[40.71905, -74.00519]},
{Hotel_name:'Marrakech Hotel New York City, New York',price:85,hotel_star:3,rating:3.2,lat_long:[40.79895, -73.96853]},
{Hotel_name:'Skyline Hotel, New York',price:158,hotel_star:3,rating:4,lat_long:[40.76425, -73.9921]},
{Hotel_name:'Club Quarters Hotel, Grand Central, New York',price:137,hotel_star:4,rating:4.4,lat_long:[40.753248, -73.974406]},
{Hotel_name:'The Time New York, New York',price:15,hotel_star:4.5,rating:4.2,lat_long:[40.761116, -73.985292]},
{Hotel_name:'Hotel Giraffe by Library Hotel Collection, New York',price:251,hotel_star:4,rating:4.8,lat_long:[40.74214, -73.98489]},
{Hotel_name:'Baccarat Hotel and Residences New York, New York',price:45,hotel_star:5,rating:4.7,lat_long:[40.760949, -73.977178]},
{Hotel_name:'The Marmara Park Avenue, New York',price:23,hotel_star:5,rating:4.4,lat_long:[40.745264, -73.981634]},
{Hotel_name:'The Library Hotel by Library Hotel Collection, New York',price:287,hotel_star:4,rating:4.8,lat_long:[40.75219, -73.97973]},
{Hotel_name:'Hotel Wales, New York',price:183,hotel_star:3.5,rating:4.1,lat_long:[40.785006, -73.955795]},
{Hotel_name:'Aloft Harlem, New York',price:143,hotel_star:3.5,rating:4.2,lat_long:[40.80921, -73.95184]},
{Hotel_name:'DoubleTree by Hilton New York City - Chelsea, New York',price:103,hotel_star:4,rating:3.9,lat_long:[40.747162, -73.991284]},
{Hotel_name:'Eurostars Wall Street, New York',price:103,hotel_star:4,rating:3.7,lat_long:[40.70523, -74.00638]},
{Hotel_name:'Holiday Inn Manhattan-Financial District, New York',price:5,hotel_star:4,rating:4.1,lat_long:[40.708333, -74.014356]},
{Hotel_name:'Loews Regency New York Hotel, New York',price:45,hotel_star:5,rating:4.5,lat_long:[40.764458, -73.968852]},
{Hotel_name:'Warwick New York, New York',price:153,hotel_star:4.5,rating:4.4,lat_long:[40.762256, -73.978264]},
{Hotel_name:'Fairfield Inn & Suites New York Midtown Manhattan/Penn Station, New York',price:134,hotel_star:3,rating:4.4,lat_long:[40.752083, -73.995273]},
{Hotel_name:'The High Line Hotel, New York',price:1,hotel_star:4,rating:4.4,lat_long:[40.746122, -74.005301]},
{Hotel_name:'Bentley Hotel, New York',price:12,hotel_star:4,rating:3.9,lat_long:[40.76055, -73.95833]},
{Hotel_name:'The Paul Hotel NYC-Chelsea, an Ascend Hotel Collection Member, New York',price:116,hotel_star:4,rating:3.9,lat_long:[40.746222, -73.98907]},
{Hotel_name:'Courtyard New York Manhattan/Times Square West, New York',price:111,hotel_star:3.5,rating:4.5,lat_long:[40.754352, -73.992682]},
{Hotel_name:'Hudson New York, Central Park, New York',price:14,hotel_star:4,rating:3.3,lat_long:[40.768355, -73.984757]},
{Hotel_name:'The London NYC, New York',price:427,hotel_star:4.5,rating:4.2,lat_long:[40.763281, -73.980648]},
{Hotel_name:'AKA Times Square, New York',price:25,hotel_star:4,rating:4.5,lat_long:[40.756635, -73.984299]},
{Hotel_name:'Hotel Elysee by Library Hotel Collection, New York',price:212,hotel_star:4,rating:4.7,lat_long:[40.760061, -73.973013]},
{Hotel_name:'Hyatt House New York/Chelsea, New York',price:12,hotel_star:3.5,rating:4.4,lat_long:[40.746185, -73.990413]},
{Hotel_name:'Hyatt Centric Times Square New York, New York',price:21,hotel_star:4.5,rating:4.5,lat_long:[40.75739, -73.984171]},
{Hotel_name:'Hampton Inn Manhattan/Times Square Central, New York',price:12,hotel_star:3.5,rating:4.6,lat_long:[40.755823, -73.988581]},
{Hotel_name:'Room Mate Grace Boutique Hotel, New York',price:161,hotel_star:3.5,rating:4.4,lat_long:[40.757292, -73.983926]},
{Hotel_name:'Four Seasons Hotel New York, New York',price:115,hotel_star:5,rating:4.6,lat_long:[40.761969, -73.971584]},
{Hotel_name:'The Nolitan, New York',price:10,hotel_star:3.5,rating:4.3,lat_long:[40.720719, -73.995258]},
{Hotel_name:'The Sohotel, New York',price:123,hotel_star:3,rating:4.2,lat_long:[40.71956, -73.99449]},
{Hotel_name:'Casablanca Hotel by Library Hotel Collection, New York',price:242,hotel_star:4,rating:4.8,lat_long:[40.756303, -73.985526]},
{Hotel_name:'The Evelyn Hotel, New York',price:143,hotel_star:4,rating:4.1,lat_long:[40.743809, -73.987129]},
{Hotel_name:'Mayfair New York, New York',price:123,hotel_star:3,rating:3.5,lat_long:[40.761351, -73.985825]},
{Hotel_name:'Excelsior Hotel, New York',price:231,hotel_star:3.5,rating:4.3,lat_long:[40.782949, -73.973846]},
{Hotel_name:'Washington Jefferson Hotel, New York',price:137,hotel_star:3.5,rating:3.7,lat_long:[40.763445, -73.986874]},
{Hotel_name:'Econo Lodge Times Square, New York',price:110,hotel_star:2.5,rating:3.7,lat_long:[40.760582, -73.987887]},
{Hotel_name:'The Roosevelt Hotel, New York City, New York',price:134,hotel_star:4,rating:3.4,lat_long:[40.754581, -73.977493]},
{Hotel_name:'Harlem YMCA, New York',price:7,hotel_star:2,rating:3.4,lat_long:[40.814964, -73.942843]},
{Hotel_name:'AKA Wall Street, New York',price:225,hotel_star:4,rating:4.7,lat_long:[40.708011, -74.00778]},
{Hotel_name:'Park Central Hotel New York, New York',price:5,hotel_star:4,rating:3.9,lat_long:[40.76452, -73.98078]},
{Hotel_name:'The Hotel 91, New York',price:151,hotel_star:3,rating:3.8,lat_long:[40.713724, -73.993646]},
{Hotel_name:'The NoMad Hotel, New York',price:35,hotel_star:5,rating:4.7,lat_long:[40.745066, -73.988818]},
{Hotel_name:'Wyndham Midtown 45 at New York City, New York',price:20,hotel_star:3,rating:3.7,lat_long:[40.752518, -73.972577]},
{Hotel_name:'The Ludlow Hotel, New York',price:325,hotel_star:4.5,rating:4.7,lat_long:[40.72185, -73.987473]},
{Hotel_name:'Hotel 309, New York',price:100,hotel_star:2,rating:2.6,lat_long:[40.73984, -74.00276]},
{Hotel_name:'Lotte New York Palace, New York',price:325,hotel_star:4.5,rating:4.6,lat_long:[40.758229, -73.974529]},
{Hotel_name:'Wolcott Hotel, New York',price:250,hotel_star:2.5,rating:4.1,lat_long:[40.746775, -73.986587]},
{Hotel_name:'Broadway Plaza Hotel, New York',price:14,hotel_star:3.5,rating:4.3,lat_long:[40.74441, -73.98891]},
{Hotel_name:'CITY ROOMS NYC - Chelsea, New York',price:134,hotel_star:2,rating:3.7,lat_long:[40.748651, -73.99604]},
{Hotel_name:'Empire Hotel, New York',price:175,hotel_star:4,rating:3.7,lat_long:[40.771583, -73.982599]},
{Hotel_name:'Hotel 31, New York',price:106,hotel_star:2,rating:4,lat_long:[40.74473, -73.98165]},
{Hotel_name:'Arthouse Hotel New York City, New York',price:135,hotel_star:4,rating:4.3,lat_long:[40.782246, -73.980251]},
{Hotel_name:'Marriott Vacation Club Pulse, New York City, New York',price:134,hotel_star:4,rating:4.2,lat_long:[40.751112, -73.985]},
{Hotel_name:'The Gotham Hotel, New York',price:15,hotel_star:4.5,rating:4,lat_long:[40.75566, -73.97814]},
{Hotel_name:'Embassy Suites by Hilton New York Midtown Manhattan, New York',price:107,hotel_star:3.5,rating:4.4,lat_long:[40.75133, -73.98583]},
{Hotel_name:'Omni Berkshire Place, New York',price:17,hotel_star:4.5,rating:4.4,lat_long:[40.759269, -73.975015]},
{Hotel_name:'Travel Inn Hotel, New York',price:160,hotel_star:2.5,rating:3.9,lat_long:[40.75993, -73.99612]},
{Hotel_name:'NobleDEN Hotel, New York',price:14,hotel_star:4,rating:4.7,lat_long:[40.719155, -73.996884]},
{Hotel_name:'East Village Hotel, New York',price:188,hotel_star:3,rating:4.1,lat_long:[40.728272, -73.985079]},
{Hotel_name:'The Westin New York at Times Square, New York',price:175,hotel_star:4.5,rating:4.2,lat_long:[40.757788, -73.989024]},
{Hotel_name:'The Knickerbocker Hotel, New York',price:236,hotel_star:5,rating:4.5,lat_long:[40.755751, -73.986261]},
{Hotel_name:'Mandarin Oriental, New York, New York',price:85,hotel_star:5,rating:4.6,lat_long:[40.769193, -73.982828]},
{Hotel_name:'Club Quarters Hotel, World Trade Center, New York',price:143,hotel_star:4,rating:4.4,lat_long:[40.709469, -74.013942]},
{Hotel_name:'Dream Downtown, New York',price:150,hotel_star:4.5,rating:3.8,lat_long:[40.741953, -74.003689]},
{Hotel_name:'AKA Tribeca, New York',price:224,hotel_star:4,rating:4.5,lat_long:[40.71525, -74.00943]},
{Hotel_name:'Midtown Convention Center Hotel, New York',price:184,hotel_star:3,rating:3,lat_long:[40.757614, -73.998516]},
{Hotel_name:'The James New York- SoHo, New York',price:253,hotel_star:4.5,rating:4.1,lat_long:[40.722835, -74.004712]},
{Hotel_name:'6 Columbus Central Park a Sixty Hotel, New York',price:10,hotel_star:4.5,rating:3.8,lat_long:[40.767795, -73.983016]},
{Hotel_name:'Millennium Times Square New York, New York',price:180,hotel_star:4,rating:3.8,lat_long:[40.756889, -73.984902]},
{Hotel_name:'U Hotel Fifth Avenue, New York',price:10,hotel_star:3,rating:4,lat_long:[40.74918, -73.98403]},
{Hotel_name:'New World Hotel, New York',price:71,hotel_star:1.5,rating:1.8,lat_long:[40.717586, -73.995256]},
{Hotel_name:'Aloft Manhattan Downtown - Financial District, New York',price:10,hotel_star:3,rating:4.4,lat_long:[40.710315, -74.006783]},
{Hotel_name:'Salisbury Hotel, New York',price:88,hotel_star:3,rating:3.7,lat_long:[40.764841, -73.978404]},
{Hotel_name:'The Bowery House, New York',price:10,hotel_star:2,rating:3.1,lat_long:[40.72194, -73.9934]},
{Hotel_name:'Flatiron Hotel, New York',price:14,hotel_star:4,rating:3.3,lat_long:[40.743933, -73.989383]},
{Hotel_name:'Days Hotel by Wyndham on Broadway NYC, New York',price:7,hotel_star:2.5,rating:2.9,lat_long:[40.793184, -73.972293]},
{Hotel_name:'Carvi Hotel New York, New York',price:11,hotel_star:3,rating:4.2,lat_long:[40.75917, -73.96926]},
{Hotel_name:'Hotel Boutique at Grand Central, New York',price:137,hotel_star:4,rating:4.4,lat_long:[40.753288, -73.974427]},
{Hotel_name:'The Wall Street Inn, New York',price:134,hotel_star:3,rating:4.4,lat_long:[40.704656, -74.010462]},
{Hotel_name:'San Carlos Hotel, New York',price:184,hotel_star:4.5,rating:4.5,lat_long:[40.756067, -73.971343]},
{Hotel_name:'Four Points by Sheraton Manhattan SoHo Village, New York',price:10,hotel_star:3.5,rating:4.1,lat_long:[40.72718, -74.00601]},
{Hotel_name:'Off Soho Suites Hotel, New York',price:17,hotel_star:2,rating:3.7,lat_long:[40.721325, -73.992657]},
{Hotel_name:'World Center Hotel, New York',price:14,hotel_star:4,rating:4.3,lat_long:[40.709469, -74.013942]},
{Hotel_name:'Fitzpatrick Grand Central, New York',price:158,hotel_star:4,rating:4.4,lat_long:[40.75248, -73.97446]},
{Hotel_name:'The Jewel facing Rockefeller Center, New York',price:161,hotel_star:4,rating:4.4,lat_long:[40.75958, -73.977802]},
{Hotel_name:'citizenM New York Times Square, New York',price:174,hotel_star:4,rating:4.7,lat_long:[40.761717, -73.98481]},
{Hotel_name:'Avalon Hotel, New York',price:135,hotel_star:4,rating:4.2,lat_long:[40.74673, -73.98448]},
{Hotel_name:'Hilton Garden Inn New York/Manhattan-Midtown East, New York',price:11,hotel_star:3.5,rating:4.3,lat_long:[40.756839, -73.969297]},
{Hotel_name:'Viceroy Central Park New York, New York',price:20,hotel_star:4,rating:3.9,lat_long:[40.764793, -73.978305]},
{Hotel_name:'The Pearl New York, New York',price:152,hotel_star:4,rating:4.6,lat_long:[40.761267, -73.98565]},
{Hotel_name:'TRYP By Wyndham Times Square South, New York',price:124,hotel_star:4.5,rating:4.1,lat_long:[40.753587, -73.994731]},
{Hotel_name:'The Mansfield Hotel, New York',price:8,hotel_star:3.5,rating:3.5,lat_long:[40.755184, -73.980996]},
{Hotel_name:'Dream Midtown, New York',price:150,hotel_star:4,rating:4.1,lat_long:[40.764583, -73.981828]},
{Hotel_name:'Trump International Hotel & Tower New York, New York',price:524,hotel_star:5,rating:4.6,lat_long:[40.769045, -73.981248]},
{Hotel_name:'Life Hotel NoMad, New York',price:125,hotel_star:4,rating:4,lat_long:[40.747044, -73.987129]},
{Hotel_name:'The Westin New York Grand Central, New York',price:125,hotel_star:4.5,rating:4.2,lat_long:[40.750407, -73.973775]},
{Hotel_name:'Hyatt Place New York Midtown South, New York',price:12,hotel_star:3.5,rating:4.4,lat_long:[40.750584, -73.985666]},
{Hotel_name:'Q&A Residential Hotel, New York',price:224,hotel_star:4,rating:4.7,lat_long:[40.706287, -74.007859]},
{Hotel_name:'Kimpton Hotel Eventi, New York',price:18,hotel_star:5,rating:4.5,lat_long:[40.74719, -73.9897]},
{Hotel_name:'Best Western Bowery Hanbee Hotel, New York',price:104,hotel_star:3,rating:4.2,lat_long:[40.718604, -73.995259]},
{Hotel_name:'Holiday Inn Express - New York City Chelsea, New York',price:114,hotel_star:3,rating:4.1,lat_long:[40.748526, -73.994504]},
{Hotel_name:'Park Hyatt New York, New York',price:85,hotel_star:5,rating:4.4,lat_long:[40.765153, -73.979124]},
{Hotel_name:'Blue Moon Boutique Hotel, New York',price:24,hotel_star:3,rating:3.4,lat_long:[40.7186, -73.99001]},
{Hotel_name:'Cachet Boutique New York, New York',price:170,hotel_star:4,rating:3.9,lat_long:[40.760007, -73.996383]},
{Hotel_name:'AKA Central Park, New York',price:575,hotel_star:4,rating:4.4,lat_long:[40.764511, -73.975546]},
{Hotel_name:'Renaissance New York Times Square Hotel, New York',price:178,hotel_star:4,rating:4.4,lat_long:[40.75968, -73.9843]},
{Hotel_name:'Fairfield Inn & Suites by Marriott New York ManhattanChelsea, New York',price:104,hotel_star:3,rating:4.3,lat_long:[40.746377, -73.991344]},
{Hotel_name:'Renaissance New York Midtown Hotel, New York',price:237,hotel_star:4,rating:4.6,lat_long:[40.75197, -73.990898]},
{Hotel_name:'Leon Hotel, New York',price:120,hotel_star:3.5,rating:4.3,lat_long:[40.715912, -73.995339]},
{Hotel_name:'West 57th Street by Hilton Club, New York',price:542,hotel_star:4,rating:4.6,lat_long:[40.764528, -73.977775]},
{Hotel_name:'Hotel Americano, New York',price:20,hotel_star:4.5,rating:3.9,lat_long:[40.750616, -74.003311]},
{Hotel_name:'Hotel 50 Bowery NYC, New York',price:18,hotel_star:4.5,rating:4.6,lat_long:[40.715841, -73.996409]},
{Hotel_name:'Gild Hall, A Thompson Hotel, New York',price:18,hotel_star:4.5,rating:4.6,lat_long:[40.707946, -74.007114]},
{Hotel_name:'Hotel Beacon, New York',price:321,hotel_star:4,rating:4.5,lat_long:[40.780752, -73.9813]},
{Hotel_name:'St Marks Hotel, New York',price:136,hotel_star:3,rating:3.1,lat_long:[40.729411, -73.989667]},
{Hotel_name:'The Kitano Hotel New York, New York',price:274,hotel_star:4.5,rating:4.5,lat_long:[40.74962, -73.97962]},
{Hotel_name:'SIXTY Lower East Side, New York',price:10,hotel_star:4.5,rating:4,lat_long:[40.722149, -73.988817]},
{Hotel_name:'The Lexington Hotel, Autograph Collection, New York',price:140,hotel_star:4,rating:4.2,lat_long:[40.75508, -73.97338]},
{Hotel_name:'The Hilton Club - New York, New York',price:42,hotel_star:4,rating:4.3,lat_long:[40.762104, -73.978826]},
{Hotel_name:'Holiday Inn NYC - Lower East Side, New York',price:6,hotel_star:4,rating:4.3,lat_long:[40.718049, -73.986432]},
{Hotel_name:'The Kimpton Muse Hotel, New York',price:17,hotel_star:4.5,rating:4.6,lat_long:[40.757976, -73.983623]},
{Hotel_name:'Chelsea Savoy Hotel, New York',price:235,hotel_star:2,rating:4.1,lat_long:[40.744215, -73.995962]},
{Hotel_name:'The Shoreham Hotel, New York',price:143,hotel_star:4,rating:3.7,lat_long:[40.762342, -73.976519]},
{Hotel_name:'New York Marriott Marquis, New York',price:220,hotel_star:4.5,rating:4.4,lat_long:[40.758234, -73.985457]},
{Hotel_name:'Millennium Premier New York Times Square, New York',price:185,hotel_star:4,rating:4.2,lat_long:[40.756709, -73.984477]},
{Hotel_name:'W New York - Times Square, New York',price:21,hotel_star:4.5,rating:4.1,lat_long:[40.75936, -73.98512]},
{Hotel_name:'Sheraton Tribeca New York Hotel, New York',price:107,hotel_star:4,rating:4,lat_long:[40.721021, -74.004179]},
{Hotel_name:'Row NYC, New York',price:8,hotel_star:4,rating:3.4,lat_long:[40.75905, -73.98844]},
{Hotel_name:'Hotel Plaza Athenee, New York',price:53,hotel_star:5,rating:4.4,lat_long:[40.766424, -73.968437]},
{Hotel_name:'Chelsea Inn, New York',price:85,hotel_star:3,rating:3.7,lat_long:[40.738839, -73.994443]},
{Hotel_name:'Comfort Inn Times Square West, New York',price:123,hotel_star:2.5,rating:3.9,lat_long:[40.759379, -73.990832]},
{Hotel_name:'The Bernic Hotel New York City, Tapestry Collection by Hilton, New York',price:116,hotel_star:4,rating:4.5,lat_long:[40.754242, -73.972802]},
{Hotel_name:'Residence Inn by Marriott New York Manhattan/Times Square, New York',price:16,hotel_star:3.5,rating:4.3,lat_long:[40.75273, -73.98566]},
{Hotel_name:'Archer Hotel New York, New York',price:1,hotel_star:4.5,rating:4.7,lat_long:[40.751857, -73.984879]},
{Hotel_name:'The Quin Central Park by Hilton Club, New York',price:377,hotel_star:5,rating:4.4,lat_long:[40.764263, -73.977069]},
{Hotel_name:'Sheraton New York Times Square Hotel, New York',price:16,hotel_star:4,rating:3.9,lat_long:[40.76264, -73.98213]},
{Hotel_name:'Macy Empire Apartments, New York',price:210,hotel_star:3.5,rating:3,lat_long:[40.747044, -73.987159]},
{Hotel_name:'Colonial House Inn, New York',price:177,hotel_star:3,rating:3.8,lat_long:[40.745034, -73.999937]},
{Hotel_name:'255West Guesthouse, New York',price:15,hotel_star:3.5,rating:4.5,lat_long:[40.8141, -73.946807]},
{Hotel_name:'Hilton Garden Inn New York/Central Park South-Midtown West, New York',price:10,hotel_star:3.5,rating:4.3,lat_long:[40.764324, -73.98316]},
{Hotel_name:'The Gallivant Times Square , New York',price:10,hotel_star:3.5,rating:3.7,lat_long:[40.760691, -73.98622]},
{Hotel_name:'3 West Club, New York',price:15,hotel_star:3.5,rating:4.1,lat_long:[40.759666, -73.977292]},
{Hotel_name:'Conrad New York, New York',price:27,hotel_star:5,rating:4.8,lat_long:[40.715053, -74.016008]},
{Hotel_name:'Crowne Plaza Times Square Manhattan, New York',price:105,hotel_star:4,rating:4.2,lat_long:[40.76025, -73.98478]},
{Hotel_name:'Bowery Grand Hotel, New York',price:77,hotel_star:1,rating:2.2,lat_long:[40.719014, -73.994535]},
{Hotel_name:'Blakely New York, New York',price:225,hotel_star:4.5,rating:4.4,lat_long:[40.763655, -73.979649]},
{Hotel_name:'Pod 51, New York',price:12,hotel_star:3,rating:4,lat_long:[40.755889, -73.968987]},
{Hotel_name:'Park West Hotel, New York',price:0,hotel_star:3,rating:3.2,lat_long:[40.79974, -73.95889]},
{Hotel_name:'The Standard East Village, New York',price:15,hotel_star:4,rating:4.4,lat_long:[40.727844, -73.991075]},
{Hotel_name:'Casamia 36 Hotel, New York',price:146,hotel_star:3,rating:3.7,lat_long:[40.755642, -73.997647]},
{Hotel_name:'The Frederick Hotel, New York',price:127,hotel_star:4,rating:4.3,lat_long:[40.715505, -74.009255]},
{Hotel_name:'Hotel Indigo Lower East Side New York, New York',price:178,hotel_star:4.5,rating:4.4,lat_long:[40.721736, -73.987497]},
{Hotel_name:'Hotel 32 32, New York',price:124,hotel_star:4,rating:4,lat_long:[40.746207, -73.983351]},
{Hotel_name:'Hudson River Hotel, New York',price:10,hotel_star:2.5,rating:3.7,lat_long:[40.755483, -73.99733]},
{Hotel_name:'Club Quarters Hotel, opposite Rockefeller Center, New York',price:151,hotel_star:4,rating:4.1,lat_long:[40.75982, -73.97835]},
{Hotel_name:'Clarion Hotel Park Avenue, New York',price:1,hotel_star:2.5,rating:3.7,lat_long:[40.74417, -73.98338]},
{Hotel_name:'Night Hotel Theater District, Times Square, New York',price:12,hotel_star:4,rating:3.8,lat_long:[40.757349, -73.984069]},
{Hotel_name:'The Gregory Hotel, New York',price:135,hotel_star:4,rating:4,lat_long:[40.749875, -73.985966]},
{Hotel_name:'414 Hotel, New York',price:26,hotel_star:3.5,rating:4.8,lat_long:[40.76117, -73.99117]},
{Hotel_name:'Soho Grand Hotel, New York',price:1,hotel_star:4.5,rating:4.4,lat_long:[40.721886, -74.004201]},
{Hotel_name:'Hilton Garden Inn New York/Manhattan-Chelsea, New York',price:157,hotel_star:3.5,rating:4.3,lat_long:[40.746478, -73.991579]},
{Hotel_name:'Washington Square Hotel, New York',price:308,hotel_star:3.5,rating:4.4,lat_long:[40.73226, -73.99867]},
{Hotel_name:'The Marmara Manhattan, New York',price:286,hotel_star:3.5,rating:4.2,lat_long:[40.782847, -73.947762]},
{Hotel_name:'The Inn at Irving Place, New York',price:25,hotel_star:4,rating:4.5,lat_long:[40.736064, -73.987251]},
];
  
var priceMarkers = [];
  for (var i = 0; i < hotelsdata.length; i++) {
      var color = "";
    if (hotelsdata[i].price > 400) {
      color = "Darkgreen";
    }
    else if (hotelsdata[i].price > 200) {
      color = "Lime";
    }
    else if (hotelsdata[i].price > 100) {
      color = "SeaGreen";
    }
    else {
      color = "Aquamarine";
    }
  
    priceMarkers.push(
    L.circle(hotelsdata[i].lat_long, {
      fillOpacity: 1,
      color: "white",
      fillColor: color,
      radius: hotelsdata[i].price / 3
    }).bindPopup("<h1>" + hotelsdata[i].Hotel_name + "</h1> <hr> <h3>Price: $ " + hotelsdata[i].price + "</h3> <hr> <h3>Rating: " + hotelsdata[i].rating + "</h3> <hr> <h3>Hotel Star: " + hotelsdata[i].hotel_star + "</h3> ").addTo(myMap))
  }

  var starMarkers = [];
  for (var i = 0; i < hotelsdata.length; i++) {
      var color = "";
    if (hotelsdata[i].hotel_star > 4) {
      color = "Maroon";
    }
    else if (hotelsdata[i].hotel_star > 3) {
      color = "Sienna";
    }
    else if (hotelsdata[i].hotel_star > 2) {
      color = "Tan";
    }
    else {
      color = "oldlace";
    }
  
    starMarkers.push(
    L.circle(hotelsdata[i].lat_long, {
      fillOpacity: 0.75,
      color: "white",
      fillColor: color,
      radius: hotelsdata[i].hotel_star * 17
    }).bindPopup("<h1>" + hotelsdata[i].Hotel_name + "</h1> <hr> <h3>Hotel Star: " + hotelsdata[i].hotel_star + "</h3>").addTo(myMap))
  }


var ratingMarkers = [];
  for (var i = 0; i < hotelsdata.length; i++) {
      var color = "";
    if (hotelsdata[i].rating > 4) {
      color = "MidnightBlue";
    }
    else if (hotelsdata[i].rating > 3) {
      color = "BlueViolet";
    }
    else if (hotelsdata[i].rating > 2) {
      color = "PowderBlue";
    }
    else {
      color = "CornflowerBlue";
    }
  
    ratingMarkers.push(
    L.circle(hotelsdata[i].lat_long, {
      fillOpacity: 0.75,
      color: "white",
      fillColor: color,
      radius: hotelsdata[i].rating * 15
    }).bindPopup("<h1>" + hotelsdata[i].Hotel_name + "</h1> <hr> <h3>Rating: " + hotelsdata[i].rating + "</h3>").addTo(myMap))
  }
  
  var ratinglayer = L.layerGroup(ratingMarkers);
  var pricelayer = L.layerGroup(priceMarkers);
  var starlayer = L.layerGroup(starMarkers);

  var light = L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
    attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
    maxZoom: 18,
    id: "mapbox.light",
    accessToken: API_KEY
  });
  
  var dark = L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
    attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
    maxZoom: 18,
    id: "mapbox.dark",
    accessToken: API_KEY
  });

  var baseMaps = {
    "Light": light,
    "Dark": dark
  };

  var overlayMaps = {
    "Price": pricelayer,
    "Hotel Star": starlayer,
    "Rating": ratinglayer
  };

  L.control.layers(baseMaps, overlayMaps).addTo(myMap);



