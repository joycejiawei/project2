
const API_KEY = "pk.eyJ1IjoiZWRkaWUxNjgiLCJhIjoiY2p6OTBmeWJ6MDBjMzNucDU0OHk0b2NwbCJ9.bpj8j7ST2cki5zTHCE5RwQ"


