var myMap = L.map("map", {
    center: [40.7388, -74.006],
    zoom: 13,
    layer: [light, pricelayer, ratinglayer]
  });


var airbnbdata = [
    { name:'chelsea', location:[40.7465, -74.0014], points: 4.875, price: 166.75},
{ name:'chinatown', location:[40.7158, -73.9970], points: 4.7, price: 133},
{ name:'columbus circle', location:[40.767997, -73.981934], points: 4.75, price: 185},
{ name:'east village', location:[40.7265, -73.9815], points: 4.5, price: 157.75},
{ name:'financial district', location:[40.7077, -74.0083], points: 4.813, price: 191.88},
{ name:'greenwich village', location:[40.7336, -74.0027], points: 5, price: 250},
{ name:'harlem', location:[40.8116, -73.9465], points: 4.765, price: 134.59},
{ name:'hells kitchen', location:[40.7638, -73.9918], points: 4.6, price: 166.2},
{ name:'herald sq', location:[40.7502, -73.9877], points: 4.5, price: 137},
{ name:'lower east side', location:[40.7150, -73.9843], points: 4.5, price: 137.33},
{ name:'manhattanville', location:[40.8169, -73.9558], points: 4.5, price: 94},
{ name:'midtown', location:[40.7549, -73.9840], points: 4.688, price: 164.46},
{ name:'morningside heights', location:[40.8090, -73.9624], points: 5, price: 133},
{ name:'nolita', location:[40.7230, -73.9949], points: 5, price: 192},
{ name:'river side park', location:[40.8012, -73.9723], points: 4.5, price: 186},
{ name:'soho', location:[40.7233, -74.0030], points: 4.571, price: 200.43},
{ name:'Spanish Harlem', location:[40.7957, -73.9389], points: 4.667, price: 144.33},
{ name:'time square', location:[40.7590, -73.9845], points: 4.645, price: 192.16},
{ name:'tribeca', location:[40.7163, -74.0086], points: 5, price: 500},
{ name:'turtle bay', location: [40.7571, -73.9719], points: 4.5, price: 105},
{ name:'union square', location:[40.7359, -73.9911], points: 4, price: 91},
{ name:'upper east side', location:[40.7736, -73.9566], points: 4.545, price: 146.64},
{ name:'upper west side', location:[40.7870, -73.9754], points: 5, price: 132.67},
{ name:'village', location:[40.7128, -74.0060], points: 4.5, price: 225},
{ name:'wall street', location:[40.7077, -74.0083], points: 4.8, price: 205.8},
{ name:'west village', location:[40.7347, -74.0048], points: 4.5, price: 192.33}
];

var priceMarkers = [];
  for (var i = 0; i < airbnbdata.length; i++) {
      var color = "";
    if (airbnbdata[i].price > 400) {
      color = "Darkgreen";
    }
    else if (airbnbdata[i].price > 200) {
      color = "Lime";
    }
    else if (airbnbdata[i].price > 100) {
      color = "SeaGreen";
    }
    else {
      color = "Aquamarine";
    }
  
    priceMarkers.push(
    L.circle(airbnbdata[i].location, {
      fillOpacity: 1,
      color: "white",
      fillColor: color,
      radius: airbnbdata[i].price / 3
    }).bindPopup("<h1>" + airbnbdata[i].name + "</h1> <hr> <h3>Price: $ " + airbnbdata[i].price + "</h3> <hr> <h3>Rating: " + airbnbdata[i].points + "</h3> ").addTo(myMap))
  }


  var ratingMarkers = [];
  for (var i = 0; i < airbnbdata.length; i++) {
      var color = "";
    if (airbnbdata[i].points > 4) {
      color = "MidnightBlue";
    }
    else if (airbnbdata[i].points > 3) {
      color = "BlueViolet";
    }
    else if (airbnbdata[i].points > 2) {
      color = "PowderBlue";
    }
    else {
      color = "CornflowerBlue";
    }
  
    ratingMarkers.push(
    L.circle(airbnbdata[i].location, {
      fillOpacity: 0.75,
      color: "white",
      fillColor: color,
      radius: airbnbdata[i].points * 15
    }).bindPopup("<h1>" + airbnbdata[i].name + "</h1> <hr> <h3>Rating: " + airbnbdata[i].points + "</h3>").addTo(myMap))
  }

  var ratinglayer = L.layerGroup(ratingMarkers);
  var pricelayer = L.layerGroup(priceMarkers);

  var light = L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
    attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
    maxZoom: 18,
    id: "mapbox.light",
    accessToken: API_KEY
  });
  
  var dark = L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
    attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
    maxZoom: 18,
    id: "mapbox.dark",
    accessToken: API_KEY
  });

  var baseMaps = {
    "Light": light,
    "Dark": dark
  };

  var overlayMaps = {
    "Price": pricelayer,
    "Rating": ratinglayer
  };

  L.control.layers(baseMaps, overlayMaps).addTo(myMap);